package ar.edu.centro8.ps.trabajoPractico4.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.centro8.ps.trabajoPractico4.model.Cursos;
import ar.edu.centro8.ps.trabajoPractico4.model.Docentes;

@RestController 
public class Colegio {
        

    @GetMapping("/cursos")
    public List<Cursos> listarCursos(@RequestBody Cursos c){
        List<Cursos> cursos = new ArrayList<>();
        cursos.add(c);
        return cursos;
    }

    @PostMapping("/cursos")
    public Cursos crearCurso(@RequestBody Cursos a){
         return a ;
    }

    @GetMapping("/docentes")
    public Docentes crearDocente(@RequestBody Docentes d)
    
      return d;
    
}
