package ar.edu.centro8.ps.trabajoPractico3.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController 
public class BancoController {

    @GetMapping ("/api/public/info")
    public String Bienvenida(){

        return "Bienvenida";
    }

    @GetMapping("/api/secure/saldo")
    public String Saldo(){

        return "saldo";
    }

    @PutMapping ("/api/secure/trasferencia")
    public String Trasferencia(){

        return "trasferencia";
    }

}

