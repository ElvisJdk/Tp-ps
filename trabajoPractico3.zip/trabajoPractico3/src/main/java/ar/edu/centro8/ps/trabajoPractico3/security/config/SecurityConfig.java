package ar.edu.centro8.ps.trabajoPractico3.security.config;



import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;

public class SecurityConfig {

    @Bean 
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception{
        return httpSecurity
                .csrf(csrf -> csrf.disable())
                .httpBasic(Customizer.withDefaults())
                .sessionManagement(session ->  session.sessionCreationPolicy(SessionCreationPolicy.STATELESS) )
                .authorizeHttpRequests(http -> {
            http.requestMatchers(HttpMethod.GET, "/api/public/info").permitAll();
            http.requestMatchers(HttpMethod.GET, "/api/secure/saldo").hasAuthority("READ");
            http.requestMatchers(HttpMethod.POST, "/api/secure/transferencia").hasAuthority("WRITE");
            http.anyRequest().denyAll();
                })
                .build();

    }

    @Bean 
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception{
         
        return authenticationConfiguration.getAuthenticationManager();

    }


    @Bean 
    public AuthenticationProvider authenticationProvider(){
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setPasswordEncoder(passwordEncoder());
        provider.setUserDetailsPasswordService(userDetailsPasswordService());
        return provider;
    }


    @Bean
    public UserDetailsService userDetailsService(){
        List<UserDetails> userDetails =  new ArrayList<>();
        

    }

}
