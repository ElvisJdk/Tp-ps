package ar.edu.centro8.ps.trabajoPractico3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoPractico3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
